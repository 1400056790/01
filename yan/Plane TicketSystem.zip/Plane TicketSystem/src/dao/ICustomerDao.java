package dao;

public interface ICustomerDao {
}
