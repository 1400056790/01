package bll.impl;

import bean.Flight;
import bll.IFlightService;

import java.util.Set;

public class FlightServiceImpl implements IFlightService
{
    @Override
    public void insertFlight(Flight flight) {
        System.out.println(flight);
    }

    @Override
    public Set<Flight> getAllFlights() {
        return null;
    }

    @Override
    public Flight getFlightByDepartureTime(String departureTime) {
        return null;
    }

    @Override
    public Flight getFlightByDepartureAirPort(String departureAirPort) {
        return null;
    }

    @Override
    public Flight getFlightByDestinationAirPort(String destinationAirPort) {
        return null;
    }

    @Override
    public void updateFlight(Flight flight) {

    }


}
